from google.appengine.ext import vendor

# Add any libraries installed in the "python_modules" folder.
vendor.add('python_modules')
